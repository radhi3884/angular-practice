import { PowerPipePipe } from './power-pipe.pipe';

describe('PowerPipePipe', () => {
  it('create an instance', () => {
    const pipe = new PowerPipePipe();
    expect(pipe).toBeTruthy();
  });
});

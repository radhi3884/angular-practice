import { TagPipePipe } from './tag-pipe.pipe';

describe('TagPipePipe', () => {
  it('create an instance', () => {
    const pipe = new TagPipePipe();
    expect(pipe).toBeTruthy();
  });
});
